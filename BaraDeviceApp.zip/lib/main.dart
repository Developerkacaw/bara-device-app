
import 'package:flutter/material.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:carrier_info/carrier_info.dart';
import 'package:shimmer/shimmer.dart';

void main() {
  runApp(BaraApp());
}

class BaraApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bara Development',
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String ram = '...';
  String device = '...';
  String brand = '...';
  String operator = '...';

  @override
  void initState() {
    super.initState();
    fetchDeviceInfo();
  }

  Future<void> fetchDeviceInfo() async {
    final deviceInfo = DeviceInfoPlugin();
    final androidInfo = await deviceInfo.androidInfo;

    final totalRam = androidInfo.totalPhysicalMemory != null
        ? (androidInfo.totalPhysicalMemory! / (1024 * 1024 * 1024)).toStringAsFixed(1)
        : '?';

    String simOperator = '';
    try {
      simOperator = await CarrierInfo.carrierName ?? 'Tidak Diketahui';
    } catch (e) {
      simOperator = 'Gagal Baca SIM';
    }

    setState(() {
      ram = '$totalRam GB';
      device = androidInfo.model ?? 'Tidak diketahui';
      brand = androidInfo.brand ?? 'Tidak diketahui';
      operator = simOperator;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Shimmer.fromColors(
              baseColor: Colors.red,
              highlightColor: Colors.yellow,
              child: Text(
                '✨ Bara Development ✨',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SizedBox(height: 30),
            InfoItem(title: 'RAM', value: ram),
            InfoItem(title: 'Device', value: device),
            InfoItem(title: 'Sinyal Operator', value: operator),
            InfoItem(title: 'Brand', value: brand),
            SizedBox(height: 40),
            Text(
              'Ini hanya test aplikasi',
              style: TextStyle(
                color: Colors.red,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            )
          ],
        ),
      ),
    );
  }
}

class InfoItem extends StatelessWidget {
  final String title;
  final String value;

  const InfoItem({required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 24),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('\$title:', style: TextStyle(fontSize: 18)),
          Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
